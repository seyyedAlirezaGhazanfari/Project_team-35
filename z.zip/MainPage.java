package Views;

import java.util.ArrayList;
import java.util.HashMap;

public class MainPage extends Page {
    public MainPage() {
        super("Main Menu", null);
        HashMap<String , Page> subPages = new HashMap<String, Page>();
        subPages.put("1", new RegisteringPanel("Registering Panel",this));
        subPages.put("product",new ProductsPage("Product Page" , this));
        subPages.put("offs" , new Offs("Offs Page" , this));
    }

    @Override
    public void show() {
        super.show();
    }

    @Override
    public void execute() {
        super.execute();
    }

}
